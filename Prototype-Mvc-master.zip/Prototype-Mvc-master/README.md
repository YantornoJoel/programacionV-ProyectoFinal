# Prototype-Mvc
PASOS A TENER EN CUENTA LUEGO DECLONAR
tener instalado:<br/>
1-Microsoft.EntityFrameworkCore-->Administrador de paquetes Nugets<br/>
2-Luego, abrir la consola--> Administrador de paquetes Nugets<br/>
2.1-Ingresar update-database en la consola, asi obtener la base de datos y las conexiones completas
